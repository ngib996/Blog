<?php

// BloggerBlogBundle:Page:contactEmail.txt.twig
return array (
);
