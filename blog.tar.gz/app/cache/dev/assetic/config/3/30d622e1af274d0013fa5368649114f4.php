<?php

// BloggerBlogBundle:Page:about.html.twig
return array (
);
