<?php

// BloggerBlogBundle:Blog:show.html.twig
return array (
);
