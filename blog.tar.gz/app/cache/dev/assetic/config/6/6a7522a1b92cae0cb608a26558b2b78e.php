<?php

// BloggerBlogBundle:Comment:form.html.twig
return array (
);
