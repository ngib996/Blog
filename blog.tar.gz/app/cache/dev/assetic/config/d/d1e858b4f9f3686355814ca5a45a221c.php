<?php

// BloggerBlogBundle:Comment:index.html.twig
return array (
);
