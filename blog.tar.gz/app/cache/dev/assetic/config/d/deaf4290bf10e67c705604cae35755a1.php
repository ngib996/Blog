<?php

// BloggerBlogBundle:Page:contact.html.twig
return array (
);
