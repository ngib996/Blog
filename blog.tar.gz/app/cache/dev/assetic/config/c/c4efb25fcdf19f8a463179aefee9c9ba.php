<?php

// BloggerBlogBundle:Default:index.html.twig
return array (
);
