<?php

// BloggerBlogBundle:Page:sidebar.html.twig
return array (
);
