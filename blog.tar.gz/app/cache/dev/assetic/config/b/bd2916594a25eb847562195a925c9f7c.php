<?php

// BloggerBlogBundle::layout.html.twig
return array (
  'e95c551' => 
  array (
    0 => 
    array (
      0 => '@BloggerBlogBundle/Resources/public/css/*',
    ),
    1 => 
    array (
      0 => '?yui_css',
    ),
    2 => 
    array (
      'output' => '_controller/css/blogger.css',
      'name' => 'e95c551',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
