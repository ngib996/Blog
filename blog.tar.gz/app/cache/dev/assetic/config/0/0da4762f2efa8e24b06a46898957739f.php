<?php

// BloggerBlogBundle:Comment:create.html.twig
return array (
);
