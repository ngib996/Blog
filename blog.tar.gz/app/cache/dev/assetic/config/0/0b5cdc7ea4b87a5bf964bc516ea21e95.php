<?php

// BloggerBlogBundle:Page:index.html.twig
return array (
);
